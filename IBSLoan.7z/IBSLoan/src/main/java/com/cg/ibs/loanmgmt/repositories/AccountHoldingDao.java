package com.cg.ibs.loanmgmt.repositories;

import java.util.List;
import java.util.Set;

import com.cg.ibs.loanmgmt.models.AccountHolding;
import com.cg.ibs.loanmgmt.models.CustomerBean;

public interface AccountHoldingDao {
	 Set<AccountHolding> getSavingAccountListByUci(CustomerBean customer);
}
