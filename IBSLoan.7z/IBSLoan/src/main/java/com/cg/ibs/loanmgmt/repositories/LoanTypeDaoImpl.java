package com.cg.ibs.loanmgmt.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.sun.istack.logging.Logger;

@Repository("LoanTypeDao")
public class LoanTypeDaoImpl implements LoanTypeDao{
	private static Logger LOGGER = Logger.getLogger(LoanTypeDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;
	
	
	public LoanTypeBean getLoanTypeByTypeID(Integer typeId) {
		LOGGER.info("Fetching loan details by Loan Type ID ");
		return entityManager.find(LoanTypeBean.class, typeId);
	}

	
}