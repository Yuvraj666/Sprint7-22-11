package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface ApplyPreClosureService {
	List<LoanMaster> getApprovedLoanListByUci(CustomerBean customer);

	boolean verifyPreClosureApplicable(BigInteger loanAccNum);

	LoanMaster getLoanDetails(BigInteger loanAccNumber);

	void updatePreClosure(LoanMaster loanMaster);
}
