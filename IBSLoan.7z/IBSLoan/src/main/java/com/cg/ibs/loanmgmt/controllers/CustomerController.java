package com.cg.ibs.loanmgmt.controllers;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanDetailsDisplay;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.models.LoanStatus;
import com.cg.ibs.loanmgmt.models.LoanTypeBean;
import com.cg.ibs.loanmgmt.models.TransactionBean;
import com.cg.ibs.loanmgmt.services.ApplyLoanService;
import com.cg.ibs.loanmgmt.services.ApplyPreClosureService;
import com.cg.ibs.loanmgmt.services.CustomerService;
import com.cg.ibs.loanmgmt.services.PayEmiService;
import com.cg.ibs.loanmgmt.services.ViewHistoryService;

@Controller
@Scope("session")
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private ViewHistoryService viewHistoryService;
	@Autowired
	private ApplyPreClosureService applyPreClosureService;
	@Autowired
	private PayEmiService payEmiService;
	private LoanTypeBean loanTypeBean = new LoanTypeBean();
	CustomerBean loggedInCustomer = new CustomerBean();
	private LoanMaster globalLoanMaster = new LoanMaster();
	private LoanMaster preClosureLoan = new LoanMaster();

	@RequestMapping(value = "/loggedIn")
	public String showHome() {
		return "loggedinCustomerPage";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/customer")
	public ModelAndView loginRole(@RequestParam("userId") String userId) {
		ModelAndView modelAndView = new ModelAndView();
		loggedInCustomer = customerService.getCustomer(userId);
		modelAndView.addObject("loginVerified", "Welcome " + customerService.getCustomer(userId).getFirstName());
		modelAndView.setViewName("loggedinCustomerPage");
		return modelAndView;
	}

	@RequestMapping(value = "/addLoan", method = RequestMethod.GET)
	public String showNewDeptPage() {
		return "addLoan";
	}

	@RequestMapping(value = "/homeCalculateEMI")
	public ModelAndView getDetailsForHomeLoan() {
		ModelAndView modelAndView = new ModelAndView();
		Integer typeId = 1;
		try {
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			modelAndView.setViewName("homeCalculateEMI");
			globalLoanMaster.setTypeId(typeId);
			globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());

		} catch (Exception exc) {
			String message = "No Such Loan Type; Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/homeCalculateEMI2")
	public ModelAndView calculateEmi(@ModelAttribute LoanMaster loanMaster) {
		ModelAndView modelAndView = new ModelAndView();
		try {
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
			globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
			globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
			globalLoanMaster.setBalance(loanMaster.getLoanAmount());
			globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
			modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
			modelAndView.setViewName("homeCalculateEMI");
		} catch (Exception exc) {
			String message = "No Such Loan Type Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;

	}

	@RequestMapping(value = "/homeCalculateEMI3")
	public ModelAndView displayTable() {
		ModelAndView modelAndView = new ModelAndView();
		try {
			List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
			LoanMaster loanMaster = globalLoanMaster;
			for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
				BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
				LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
				tableList.add(display);
			}
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			modelAndView.addObject("tableDisplay", tableList);
			modelAndView.setViewName("homeCalculateEMI");
		} catch (Exception exc) {
			String message = "No Such Loan Detail Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/educationCalculateEMI")
	public ModelAndView getDetailsForEducationLoan() {
		ModelAndView modelAndView = new ModelAndView();
		Integer typeId = 2;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		modelAndView.setViewName("educationCalculateEMI");
		globalLoanMaster.setTypeId(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		return modelAndView;
	}

	@RequestMapping(value = "/educationCalculateEMI2")
	public ModelAndView calculateEmi1(@ModelAttribute LoanMaster loanMaster) {
		ModelAndView modelAndView = new ModelAndView();
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
		globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
		globalLoanMaster.setBalance(loanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
		modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
		modelAndView.setViewName("educationCalculateEMI");
		return modelAndView;

	}

	@RequestMapping(value = "/educationalCalculateEMI3")
	public ModelAndView displayTable1() {
		ModelAndView modelAndView = new ModelAndView();
		try {
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
			LoanMaster loanMaster = globalLoanMaster;
			for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
				BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
				LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
				tableList.add(display);
			}
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			modelAndView.addObject("tableDisplay", tableList);
			modelAndView.setViewName("homeCalculateEMI");
		} catch (Exception exc) {
			String message = "No Such Loan Detail Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/personalCalculateEMI")
	public ModelAndView getDetailsForPersonalLoan() {
		ModelAndView modelAndView = new ModelAndView();
		Integer typeId = 3;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		modelAndView.setViewName("personalCalculateEMI");
		globalLoanMaster.setTypeId(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		return modelAndView;
	}

	@RequestMapping(value = "/personalCalculateEMI2")
	public ModelAndView calculateEmi2(@ModelAttribute LoanMaster loanMaster) {
		ModelAndView modelAndView = new ModelAndView();
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
		globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
		globalLoanMaster.setBalance(loanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
		modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
		modelAndView.setViewName("personalCalculateEMI");
		return modelAndView;

	}

	@RequestMapping(value = "/personalCalculateEMI3")
	public ModelAndView displayTable2() {
		ModelAndView modelAndView = new ModelAndView();
		try {
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
			LoanMaster loanMaster = globalLoanMaster;
			for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
				BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
				LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
				tableList.add(display);
			}
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			modelAndView.addObject("tableDisplay", tableList);
			modelAndView.setViewName("homeCalculateEMI");
		} catch (Exception exc) {
			String message = "No Such Loan Detail Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/vehicleCalculateEMI")
	public ModelAndView getDetailsForVehicleLoan() {
		ModelAndView modelAndView = new ModelAndView();
		Integer typeId = 4;
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(typeId);
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		modelAndView.setViewName("vehicleCalculateEMI");
		globalLoanMaster.setTypeId(typeId);
		globalLoanMaster.setLoanInterest(loanTypeBean.getInterestRate());
		return modelAndView;
	}

	@RequestMapping(value = "/vehicleCalculateEMI2")
	public ModelAndView calculateEmi3(@ModelAttribute LoanMaster loanMaster) {
		ModelAndView modelAndView = new ModelAndView();
		loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
		modelAndView.addObject("loanTypeBean", loanTypeBean);
		loanMaster.setLoanInterest(globalLoanMaster.getLoanInterest());
		globalLoanMaster.setEmiAmount(applyLoanService.calculateEmi(loanMaster).getEmiAmount());
		globalLoanMaster.setLoanAmount(loanMaster.getLoanAmount());
		globalLoanMaster.setBalance(loanMaster.getLoanAmount());
		globalLoanMaster.setLoanTenure(loanMaster.getLoanTenure());
		modelAndView.addObject("emi", globalLoanMaster.getEmiAmount());
		modelAndView.setViewName("vehicleCalculateEMI");
		return modelAndView;

	}

	@RequestMapping(value = "/vehicleCalculateEMI3")
	public ModelAndView displayTable3() {
		ModelAndView modelAndView = new ModelAndView();
		try {
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			List<LoanDetailsDisplay> tableList = new ArrayList<LoanDetailsDisplay>();
			LoanMaster loanMaster = globalLoanMaster;
			for (int i = 0; i < loanMaster.getLoanTenure(); i++) {
				BigDecimal interest = applyLoanService.calculatePaidInterest(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				BigDecimal principle = applyLoanService.calculatePaidPrinciple(loanMaster).setScale(4,
						RoundingMode.HALF_UP);
				loanMaster.setBalance(loanMaster.getBalance().subtract(principle).setScale(4, RoundingMode.HALF_UP));
				LoanDetailsDisplay display = new LoanDetailsDisplay(loanMaster.getEmiAmount(), principle, interest);
				tableList.add(display);
			}
			loanTypeBean = applyLoanService.getLoanTypeByTypeID(globalLoanMaster.getTypeId());
			modelAndView.addObject("loanTypeBean", loanTypeBean);
			modelAndView.addObject("tableDisplay", tableList);
			modelAndView.setViewName("homeCalculateEMI");
		} catch (Exception exc) {
			String message = "No Such Loan Detail Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/savingsAccountDetails")
	public ModelAndView getSavingsAccount() {
		ModelAndView modelAndView = new ModelAndView();
		try {
			loggedInCustomer.setAccountHoldings(applyLoanService.getSavingAccountListByUci(loggedInCustomer));
			modelAndView.addObject("tableList", loggedInCustomer.getAccountHoldings());
			modelAndView.setViewName("savingsAccountDetailsPage");
		} catch (Exception exc) {
			String message = "No Such Loan Detail Present.";
			modelAndView.addObject("message", message);
			modelAndView.setViewName("errorPage");
		}
		return modelAndView;

	}

	@RequestMapping(value = "/loanApplied")
	public ModelAndView loanSentForVerify(@RequestParam("optRadio") BigInteger accNo) {
		ModelAndView modelAndView = new ModelAndView();
		globalLoanMaster.setStatus(LoanStatus.DOCUMENT_PENDING);
		globalLoanMaster.setBalance(globalLoanMaster.getLoanAmount());
		globalLoanMaster.setAppliedDate(LocalDate.now());
		globalLoanMaster.setUci(loggedInCustomer.getUci());
		applyLoanService.sendLoanForVerification(globalLoanMaster, accNo);
		System.out.println(globalLoanMaster.getApplicationNumber());
		return new ModelAndView("uploadFilePage", "appNum", globalLoanMaster.getApplicationNumber());

	}

	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView uploadMultipleFileHandler(@RequestParam("file") MultipartFile[] files) {
		ModelAndView modelAndView = new ModelAndView();
		String message = "";
		for (int i = 0; i < files.length; i++) {
			DocumentBean document = new DocumentBean();
			document.setApplicationNumber(globalLoanMaster.getApplicationNumber());
			MultipartFile file = files[i];
			try {
				byte[] bytes = file.getBytes();
				if (i == 0) {
					document.setAadharCard(bytes);
				} else if (i == 1) {
					if (globalLoanMaster.getTypeId() == 1) {
						document.setProperty_collateral(bytes);
					}
					if (globalLoanMaster.getTypeId() == 2) {
						document.setAdmissionLetter(bytes);
					}
					if (globalLoanMaster.getTypeId() == 3) {
						document.setPanCard(bytes);
					}
					if (globalLoanMaster.getTypeId() == 4) {
						document.setVehicleRc(bytes);
					}
				}
				message = message + "You successfully uploaded file!";
				applyLoanService.uploadDocument(document);
			} catch (Exception e) {
				message = "You failed to upload " + e.getMessage();
			}
		}
		applyLoanService.updateLoanForVerification(globalLoanMaster);
		return new ModelAndView("uploadFilePage", "message", message);
	}

	@RequestMapping("/loanAppliedPage")
	public String loanApplied() {
		return "loanAppliedPage";
	}

	@RequestMapping(value = "/submit")
	public ModelAndView successUpload() {
		ModelAndView modelAndView = new ModelAndView();
		return modelAndView;

	}

	@RequestMapping(value = "/payEmi")
	public ModelAndView sendLoansWithEmi() {
		List<LoanMaster> loansWithDueEmi = payEmiService.getApprovedLoanListByUci(loggedInCustomer);
		return new ModelAndView("payEmi", "loansWithDueEmi", loansWithDueEmi);
	}

	@RequestMapping(value = "/payEmi1")
	public ModelAndView selectLoanForEmi(@RequestParam("loanNumber") BigInteger loanNumber) {
		ModelAndView modelAndView = new ModelAndView();
		List<LoanMaster> loansWithDueEmi = payEmiService.getApprovedLoanListByUci(loggedInCustomer);
		modelAndView.addObject("loansWithDueEmi", loansWithDueEmi);
		modelAndView.addObject("lNumber", loanNumber);
		globalLoanMaster.setLoanAccountNumber(loanNumber);
		modelAndView.setViewName("payEmi");
		return modelAndView;
	}

	@RequestMapping(value = "/payEmi2")
	public ModelAndView updateLoanPostEmi() {
		ModelAndView modelAndView = new ModelAndView();
		globalLoanMaster = payEmiService.getLoanByLoanNum(globalLoanMaster.getLoanAccountNumber());
		modelAndView.setViewName("payEmi");
		long diffDays = ChronoUnit.DAYS.between(LocalDate.now(), globalLoanMaster.getNextEmiDate());
		System.out.println(diffDays);
		if (diffDays <= 3) {
			modelAndView.addObject("msg", "EMI paid.Thank You!");
			globalLoanMaster.setNumOfEmisPaid(globalLoanMaster.getNumOfEmisPaid() + 1);
			globalLoanMaster.setNextEmiDate(globalLoanMaster.getNextEmiDate().plusMonths(1));
			globalLoanMaster = payEmiService.updateLoanPostEmi(globalLoanMaster);
			modelAndView.addObject("updatedLoan", globalLoanMaster);
		} else {
			modelAndView.addObject("msg", "The EMI for this month has already been paid.");
		}

		return modelAndView;
	}

	@RequestMapping(value = "/payEmi3")
	public ModelAndView showTransaction() {
		ModelAndView modelAndView = new ModelAndView();
		globalLoanMaster = payEmiService.getLoanByLoanNum(globalLoanMaster.getLoanAccountNumber());
		modelAndView.setViewName("payEmi");
		long diffDays = ChronoUnit.DAYS.between(LocalDate.now(), globalLoanMaster.getNextEmiDate());
		System.out.println(diffDays);
		if (diffDays <= 3) {
			TransactionBean transactionDebit = payEmiService.createDebitTransaction(globalLoanMaster);
			modelAndView.addObject("transDr", transactionDebit);
			TransactionBean transactionCredit = payEmiService.createCreditTransaction(globalLoanMaster);
			modelAndView.addObject("transCr", transactionCredit);
			modelAndView.addObject("updatedLoan", globalLoanMaster);
		} else {
			TransactionBean transactionDebit = null;
			modelAndView.addObject("transDr", transactionDebit);
			TransactionBean transactionCredit = null;
			modelAndView.addObject("transCr", transactionCredit);
			modelAndView.addObject("updatedLoan", globalLoanMaster);
		}
		return modelAndView;

	}

	@RequestMapping(value = "/viewHistory")
	public ModelAndView displayLoans() {
		ModelAndView modelAndView = new ModelAndView();
		List<LoanMaster> allLoans = viewHistoryService.getAllLoans(loggedInCustomer);
		modelAndView.addObject("allLoans", allLoans);
		modelAndView.setViewName("viewHistory");
		return modelAndView;

	}

	@RequestMapping(value = "/viewHistory1")
	public ModelAndView sortLoans(@RequestParam("choiceSort") String fieldSort) {
		ModelAndView mv1 = new ModelAndView();
		List<LoanMaster> allLoans = viewHistoryService.getAllLoans(loggedInCustomer);
		mv1.addObject("allLoans", allLoans);
		List<LoanMaster> sortedLoans = viewHistoryService.sortLoans(allLoans, fieldSort);
		mv1.addObject("sortedLoans", sortedLoans);
		mv1.setViewName("viewHistory");
		return mv1;
	}

	@RequestMapping(value = "/applyPreClosurePage")
	public ModelAndView showPreClosureLoans() {
		ModelAndView modelAndView = new ModelAndView();
		List<LoanMaster> preClosureList = new ArrayList<>();
		List<LoanMaster> listTemp = new ArrayList<>();
		listTemp = applyPreClosureService.getApprovedLoanListByUci(loggedInCustomer);
		if (listTemp.isEmpty()) {
			System.out.println("No Active Loans");
		} else {

			for (LoanMaster loanMaster : listTemp) {
				if (loanMaster.getStatus().equals(LoanStatus.APPROVED)) {
//					if (applyPreClosureService.verifyPreClosureApplicable(loanMaster.getLoanAccountNumber())) {
					preClosureList.add(loanMaster);
//					}
				}
			}
		}

		modelAndView.addObject("preClosureList", preClosureList);
		modelAndView.setViewName("applyPreClosurePage");
		return modelAndView;
	}

	@RequestMapping(value = "/applyPreClosure1")
	public ModelAndView selectLoanVerify(@RequestParam("optRadio") BigInteger loanAccountNumber) {
		ModelAndView modelAndView = new ModelAndView();
		globalLoanMaster.setLoanAccountNumber(loanAccountNumber);
		System.out.println(globalLoanMaster.getLoanAccountNumber());
		return new ModelAndView("applyPreClosurePage", "lAccountNo", globalLoanMaster.getLoanAccountNumber());
	}

	@RequestMapping(value = "applyPreClosure2")
	public ModelAndView showPreClosureLoanDetails(BigInteger loanAccNumber) {
		ModelAndView modelAndView = new ModelAndView();
		preClosureLoan = applyPreClosureService.getLoanDetails(globalLoanMaster.getLoanAccountNumber());
		return new ModelAndView("applyPreClosurePage", "preClosureLoan", preClosureLoan);

	}

	@RequestMapping(value = "applyPreClosure3")
	public ModelAndView showPreClosureMessage() {
		ModelAndView modelAndView = new ModelAndView();
		applyPreClosureService.updatePreClosure(preClosureLoan);
		String message = "Your PreClosure has been applied and sent for verification!";
		return new ModelAndView("applyPreClosurePage", "message", message);

	}
}
